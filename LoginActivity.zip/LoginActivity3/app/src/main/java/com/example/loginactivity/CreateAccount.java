package com.example.loginactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class CreateAccount extends AppCompatActivity {
    private EditText namer;
    private EditText fnamer;
    private EditText emailr;
    private EditText passwordr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        namer = findViewById(R.id.name);
        fnamer = findViewById(R.id.fname);
        emailr = findViewById(R.id.email);
        passwordr = findViewById(R.id.password);
        Button createAccountButton = findViewById(R.id.create);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }


        });
    }
        private void createAccount() {
            String username = namer.getText().toString();
            String familyname = fnamer.getText().toString();
            String email = emailr.getText().toString();
            String password = passwordr.getText().toString();


            ParseUser user = new ParseUser();
            user.setUsername(username);
            user.put("familyname", familyname);
            user.setEmail(email);
            user.setPassword(password);


            user.signUpInBackground(new SignUpCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        // Account creation successful
                        Toast.makeText(CreateAccount.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                        finish(); // Close the create account activity
                    } else {
                        // Account creation failed, show an error message
                        Toast.makeText(CreateAccount.this, "Account creation failed. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        }


